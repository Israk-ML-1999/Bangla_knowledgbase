# Bangla/English RAG Chatbot (FastAPI)

## Objective
A Retrieval-Augmented Generation (RAG) chatbot that answers user queries in Bangla or English, using a Bangla PDF book as its knowledge base. The system extracts text and tables from the PDF, builds a FAISS vector store with multilingual embeddings, and uses OpenAI's API to generate concise, MCQ-style answers. User interaction is via FastAPI's Swagger UI.

## Features
- Accepts queries in Bangla or English
- Cleans and chunks PDF text/tables, removes images
- Embeds with `sentence-transformers/paraphrase-multilingual-MiniLM-L12-v2`
- Stores chunks in FAISS vector DB (long-term memory)
- Maintains short-term memory (recent chat history)
- Uses OpenAI API (e.g., GPT-4) for answer generation
- Returns only the answer (no explanation)
- FastAPI backend with Swagger UI for chat

## Setup
1. **Clone the repo and add your PDF to `data/` as `HSC26-Bangla1st-Paper.pdf`**
2. **Install dependencies:**
   ```bash
   pip install -r requirements.txt
   ```
3. **Set your OpenAI API key in a `.env` file:**
   ```env
   OPENAI_API_KEY=your_openai_api_key_here
   ```
4. **Build the vector store:**
   ```bash
   python modules/pdf_index_builder.py
   ```
5. **Run the FastAPI app:**
   ```bash
   uvicorn main:app --reload
   ```
6. **Open Swagger UI:**
   Visit [http://localhost:8000/docs](http://localhost:8000/docs)

## File Structure
```
project-root/
├── main.py                  # FastAPI app
├── requirements.txt         # Dependencies
├── README.md                # This file
├── .env                     # OpenAI API key
├── data/
│   └── HSC26-Bangla1st-Paper.pdf  # Bangla PDF knowledge base
├── modules/
│   ├── pdf_index_builder.py # PDF text/table extraction, chunking, embedding, FAISS
│   ├── retriever.py         # FAISS-based retriever
│   └── memory.py            # Short-term memory (chat history)
├── vector_store/
│   ├── kb_index.faiss       # FAISS index
│   └── kb_metadata.pkl      # Chunk metadata
```

## Usage
- Use the `/chat` endpoint in Swagger UI to ask questions in Bangla or English.
- The system will return only the answer (no explanation), based on the PDF content.

## Notes
- Only digital text and tables are used; images/graphics are ignored.
- Embeddings are multilingual, so both Bangla and English queries are supported.
- For best results, ensure your PDF is high quality and text-based.

## Author
- Adapted for your requirements by AI assistant 