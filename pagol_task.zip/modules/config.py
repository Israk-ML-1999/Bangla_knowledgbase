import os
from dotenv import load_dotenv

# Load environment variables from .env
load_dotenv()

# PDF and vector store paths
PDF_PATH = os.getenv('PDF_PATH', 'data/HSC26-Bangla1st-Paper.pdf')
INDEX_PATH = os.getenv('INDEX_PATH', 'vector_store/kb_index.faiss')
METADATA_PATH = os.getenv('METADATA_PATH', 'vector_store/kb_metadata.pkl')
HISTORY_FILE = os.getenv('HISTORY_FILE', 'chat_data.json')

# Embedding model
EMBED_MODEL = os.getenv('EMBED_MODEL', 'sentence-transformers/paraphrase-multilingual-MiniLM-L12-v2')

# OpenAI API
OPENAI_API_KEY = os.getenv('OPENAI_API_KEY')
OPENAI_MODEL = os.getenv('OPENAI_MODEL', 'gpt-3.5-turbo')

# Chunking
CHUNK_SIZE = int(os.getenv('CHUNK_SIZE', 256))
CHUNK_OVERLAP = int(os.getenv('CHUNK_OVERLAP', 64))

# Short-term memory
SHORT_TERM_HISTORY = int(os.getenv('SHORT_TERM_HISTORY', 5)) 