from langchain_community.vectorstores import FAISS
from langchain_community.embeddings import HuggingFaceEmbeddings
from modules.config import INDEX_PATH, EMBED_MODEL
import os

class Retriever:
    def __init__(self):
        self.embeddings = HuggingFaceEmbeddings(model_name=EMBED_MODEL)
        # Load the vectorstore from the directory containing index.faiss and index.pkl
        self.vectorstore = FAISS.load_local(
            os.path.dirname(INDEX_PATH),
            self.embeddings,
            allow_dangerous_deserialization=True
        )

    def retrieve(self, query, top_k=3):
        docs = self.vectorstore.similarity_search(query, k=top_k)
        # docs is a list of langchain.schema.Document objects
        return [doc.page_content for doc in docs] 