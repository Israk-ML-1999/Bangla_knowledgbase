import os
import pickle
import pandas as pd
from PyPDF2 import PdfReader
from sentence_transformers import SentenceTransformer
import faiss
from dotenv import load_dotenv
from modules.config import PDF_PATH, INDEX_PATH, METADATA_PATH, EMBED_MODEL, CHUNK_SIZE, CHUNK_OVERLAP
from langchain.document_loaders import PyPDFLoader
from langchain.text_splitter import RecursiveCharacterTextSplitter
from langchain.embeddings import HuggingFaceEmbeddings
from langchain.vectorstores import FAISS

os.makedirs(os.path.dirname(INDEX_PATH), exist_ok=True)

# Helper: Extract text and tables from PDF
def build_vector_store():
    # Load PDF and extract documents
    loader = PyPDFLoader(PDF_PATH)
    docs = loader.load()
    # Split text into chunks
    splitter = RecursiveCharacterTextSplitter(
        chunk_size=CHUNK_SIZE,
        chunk_overlap=CHUNK_OVERLAP
    )
    split_docs = splitter.split_documents(docs)
    # Use HuggingFace multilingual model for embeddings
    embeddings = HuggingFaceEmbeddings(model_name=EMBED_MODEL)
    # Build FAISS vector store
    vectorstore = FAISS.from_documents(split_docs, embeddings)
    vectorstore.save_local(os.path.dirname(INDEX_PATH))
    # Save metadata (the text chunks)
    with open(METADATA_PATH, "wb") as f:
        pickle.dump([doc.page_content for doc in split_docs], f)
    print(f"Vector store and metadata saved to {os.path.dirname(INDEX_PATH)}/.")

if __name__ == "__main__":
    build_vector_store() 